window.load = function() {
  alert('loaded');
};